/**
 * Automatically generated file. DO NOT MODIFY
 */
package org.torproject.jni;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "org.torproject.jni";
  public static final String BUILD_TYPE = "release";
  // Field from default config.
  public static final int VERSION_CODE = 48172;
  // Field from default config.
  public static final String VERSION_NAME = "0.4.8.17.2";
}
